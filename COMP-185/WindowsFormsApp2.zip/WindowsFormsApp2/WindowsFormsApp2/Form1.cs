﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {

        public double rate = 0;
        public Form1()
        {
            InitializeComponent();
        }





        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            rate = 0.029;

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double payment=0, interest=0, priciple=0;

            int numOfMonths = 0;

            for(int month = 1; month <= numOfMonths; ++month)
            {
                String x = new StringBuilder()

                lbPayments.Items.Add(new ("Month {0}: payment = {1}, interest= {2}, princible = {3}", month, payment, interest, principle));
            }
        }
    }
}
